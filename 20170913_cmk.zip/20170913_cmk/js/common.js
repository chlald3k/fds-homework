$(document).ready(function() {
  var menu = $('.main-menu li');
  var focus_menu = $('.main-menu span');
  var last_menu = $('.sub-menu li:last-child a')
  menu.mouseover(function() {
    $(this).find('.sub-menu').addClass('active-menu');
  }).mouseout(function() {
    $(this).find('.sub-menu').removeClass('active-menu');
  });


  focus_menu.focusin(function() {
    $('.sub-menu').removeClass('active-menu');
    $(this).siblings('.sub-menu').addClass('active-menu');
  });

  last_menu.focusout(function() {
    $(this).parents('.sub-menu').removeClass('active-menu');
  });

})