$(document).ready(function() {
  var tab = $('.tab');
  tab.on('click focusin', function(e) {
    e.preventDefault();
    $(this).parent().addClass('active').siblings().removeClass('active');
  });
});